<!--------------- INI UNTUK PRINT TEMPLATE --------------->
  <table style="width:700px; height:100px; margin-top:-0.7cm;"class="borderless">
  
    
  <tr>
    <td style="width: 80.724px; height:100px; text-align:left;vertical-align:middle;border:1px solid" rowspan="2"> 
    <img src="{{public_path('assets/Actavis-logo.png')}}" height="75px" width="150px" >
    </td>
    <td style="width: 350px; height:100px; text-align:center;vertical-align:middle;border:1px solid;font-size:24px" rowspan="2">
    <p><b>WORK ORDER REQUISITION</b></p>
    </td>
    
    <td style="width: 120.724px;  text-align:center;vertical-align:middle;border:1px solid">
    <p><b>PT Actavis Indonesia</b></p>
    </td>
  </tr>  
  <tr>
    <td style="width: 120.724px;  text-align:center;vertical-align:middle;border:1px solid">
    <p><b>Page {{$pagenow}} of 2</b></p>
    </td>
  </tr>
</table>


<table style="width:700px; height:30px; margin-top:0.5cm; margin-bottom:-0.4cm" class="borderless">
  
    
  <tr>
    <td style="width: 170.724px; height:30px; text-align:left;vertical-align:top;border:1px solid" > 
    <p>Legacy Number:</p>
    <p></p>
    </td>
    <td style="width: 150px; height:30px; text-align:left;vertical-align:top;border:1px solid;" >
    <p>Revision Number:</p>
    <p></p>
    </td>
    
    <td style="width: 300.724px; height:60px;  text-align:left;vertical-align:top;border:1px solid">
    <p>Ref. to SOP:</p>
    </td>
  </tr>  
  
</table>