@forelse ($data as $show)
<tr class="foottr" style="text-align: center;">
  <td class="foot1" data-label="WO Number">{{ $show->assetcode }}</td>
  <td class="foot1" data-label="Asset">{{ $show->asset_desc }}</td>
  <td class="foot1" data-label="Asset">{{ $show->asset_measure }}</td>
  <td class="foot1">
    <a href="" class="editmodal" data-toggle="modal" data-target="#editModal" 
            data-asset="{{$show->assetcode}}" data-lastusage="{{$show->asset_last_usage}}"
            data-lastmt="{{$show->asset_last_usage_mtc}}" data-assetonuse="{{$show->asset_on_use}}"><i class="fas fa-edit"></i></a>  
  </td>
</tr>
@empty
<tr>
  <td colspan="6" style="color:red;" class="nodata">
    <center>No Data Available</center>
  </td>
</tr>
@endforelse
<tr>
  <td style="border: none !important;">
    {{ $data->links() }}
  </td>
</tr>